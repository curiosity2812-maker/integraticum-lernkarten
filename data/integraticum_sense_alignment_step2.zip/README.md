# Integraticum — step 2: German sense separation and conservative alignment

This dataset separates **individual German lexical definitions** from grammatical form descriptions and stores **word-level Russian candidate translations separately**. It does NOT claim a translation matches a sense merely because the headword matches.

`translation_ru` is populated only for a small set of explicitly mapped examples based on the actual German definitions. `unresolved_sense` means no semantic translation verification occurred. `editorially_aligned_example` is an editorial mapping, NOT independent dictionary corroboration. The German entry for Bank in this input has senses for bench/counter but no separate financial-institution definition; therefore «банк» is NOT assigned to its bench definition.

No source agreement or CEFR claims are made here. The bulk of senses remain unresolved until independent bilingual sense data is available. `publication_status` remains `not_verified` for every record.
